import java.util.Scanner;
public class textbook2_3 {
  public static void main(String[] args) {
    Scanner stdIn = new Scanner(System.in);
    System.out.print("整数値:");
    int x = stdIn.nextInt();
    System.out.print(x + "と入力しましたね。");
  }
}
