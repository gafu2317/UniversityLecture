public class textbook1_2 {
    public static void main(String[] args) {
      System.out.println("福");
      System.out.println("富");
      System.out.println("隆");
      System.out.println("大");
  }
}
