// 画面への出力を行うプログラム

class Hello {

    public static void main(String[] args) {
        System.out.println("初めてのJavaプログラム。");
        System.out.println("画面に出力しています。");
    }
}
