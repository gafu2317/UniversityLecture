public class textbook1_3 {
      public static void main(String[] args) {
      System.out.println("福");
      System.out.println("富");
      System.out.println("");
      System.out.println("隆");
      System.out.println("大");
  }
}
