// AddSeqクラスを書く
// mainメソッドを含むAddSeqTesterクラスを書く