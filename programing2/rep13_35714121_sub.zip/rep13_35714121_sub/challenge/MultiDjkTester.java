// mainメソッドを含むMultiDjkTesterクラスを書く
// MultiDjkをテストする

public class MultiDjkTester{
    public static void main(String[] args){
    }
}
