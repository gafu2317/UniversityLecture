// 例外クラスNotValidWordErrorを書く
