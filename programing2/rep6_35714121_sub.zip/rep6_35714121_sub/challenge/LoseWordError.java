// 例外クラスLoseWordErrorを書く
