// mainメソッドを含むShiritoriクラスを書く
