// mainメソッドを含むNimクラスを書く
