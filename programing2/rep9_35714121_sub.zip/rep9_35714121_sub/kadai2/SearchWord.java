// mainメソッドを含むSearchWordクラスを書く

