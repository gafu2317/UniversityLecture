// mainメソッドを含むSearchWordRecursiveクラスを書く

