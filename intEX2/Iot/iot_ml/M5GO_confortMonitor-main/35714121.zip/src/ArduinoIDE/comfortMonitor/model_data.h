#ifndef MODEL_DATA_H_
#define MODEL_DATA_H_

extern const unsigned char comfort_model_tflite[];
extern const unsigned int comfort_model_tflite_len;

#endif // MODEL_DATA_H_