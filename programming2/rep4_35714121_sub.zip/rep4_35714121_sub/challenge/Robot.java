// 抽象クラスRobotを書く
