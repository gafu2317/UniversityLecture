// mainメソッドを含むSimulatorクラスを書く
