// mainメソッドを含むTatamiRoomTesterクラスを書く
