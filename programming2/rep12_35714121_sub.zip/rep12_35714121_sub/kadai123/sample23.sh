#!/bin/sh

for i in 001 002 ; do
	echo Do something using ${i}.
done

