// Addressクラスを書く
public class Address {
}
