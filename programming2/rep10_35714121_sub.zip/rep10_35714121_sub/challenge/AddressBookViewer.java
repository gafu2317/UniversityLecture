// mainメソッドを含むをAddressBookViewerクラスを書く
public class AddressBookViewer{
}
