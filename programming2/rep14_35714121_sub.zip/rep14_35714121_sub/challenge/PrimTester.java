// mainメソッドを含むPrimTesterクラスを書く
// プリムのMSTアルゴリズムをテストする

