// インタフェースTicTacToePlayableを書く
