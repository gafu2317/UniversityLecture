// 実装クラスHumanを書く
