// 実装クラスComputerを書く
