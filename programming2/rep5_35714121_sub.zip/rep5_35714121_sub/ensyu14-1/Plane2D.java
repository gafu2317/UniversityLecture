// ２次元インタフェースPlane2Dを書く
public interface Plane2D {
  int getArea();
}