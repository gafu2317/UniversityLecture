// インタフェースUpperBoundedを書く
public interface UpperBounded{

	boolean inside(double x, double y);	

}
