// インタフェースWearableを書く．
public interface Wearable {
    void putOn();
    void putOff();
}
