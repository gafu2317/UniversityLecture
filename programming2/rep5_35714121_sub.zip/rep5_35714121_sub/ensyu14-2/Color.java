// インタフェースColorを書く．
public interface Color {
    int RED = 1;
    int BLUE = 2;
    int GREEN = 3;
    void changeColor(int color);
}
