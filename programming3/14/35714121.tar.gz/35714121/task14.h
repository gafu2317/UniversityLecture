#ifndef TASK14_H
#define TASK14_H

int* create_array(int size);
void fill_array(int *array, int size);
void print_array(int *array, int size);

#endif // TASK14_H
