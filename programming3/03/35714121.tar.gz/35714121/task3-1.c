#include <stdio.h>

int main() {
    double a;
    int b;

    a = b = 2.5;

    printf("a: %f\n", a);
    printf("b: %d\n", b);
    
    return 0;
}