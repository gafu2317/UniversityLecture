#include <stdio.h>

int main() {
    printf("学籍番号:35714121\n");
    printf("氏名:福富隆大\n");
    return 0;
}